
/**
 * Write a description of class temp here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class temp
{
    public static void main (String[] args) {
        int[] x = new int [10];
        
        x [1] = 10; 
        
        System.out.println(x[0]);
        
        
    }
}
